Welcome to PyJQ's documentation!
=================================

.. image:: https://img.shields.io/pypi/v/pyjq.svg
   :target: https://pypi.org/project/pyjq/
   :alt: PyPI Version

PyJQ is a Python tool that provides SQL-like syntax for querying JSON files, built as a wrapper around the powerful jq utility.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   installation
   usage
   api
   examples
   contribution

Indices and tables
===================

* :ref:`search`