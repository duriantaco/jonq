Installation
=============

Prerequisites
--------------

Before installing PyJQ, ensure you have the following:

* Python 3.9 or higher
* jq command line tool installed

Installing jq
--------------

PyJQ requires the jq command-line tool to be installed on your system.

For Linux (Debian/Ubuntu):

.. code-block:: bash

   sudo apt-get install jq

For macOS using Homebrew:

.. code-block:: bash

   brew install jq

For Windows using Chocolatey:

.. code-block:: bash

   choco install jq

You can verify jq is installed correctly by running:

.. code-block:: bash

   jq --version

Installing PyJQ
----------------

Install PyJQ using pip:

.. code-block:: bash

   pip install pyjq

Development Installation
-------------------------

If you want to contribute to the development of PyJQ, you can install from source:

.. code-block:: bash

   git clone https://github.com/duriantaco/pyjq.git
   cd pyjq
   pip install -e .